using System;
using System.Windows.Forms;

namespace SonocareWinForms
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            // Initialize SQLitePCL
            SQLitePCL.Batteries.Init();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
