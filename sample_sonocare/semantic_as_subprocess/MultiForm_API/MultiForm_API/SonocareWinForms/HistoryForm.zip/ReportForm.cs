using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using SonocareWinForms.Data;
using SonocareWinForms.Models;
using SonocareWinForms.Services;
using System.Reflection;

namespace SonocareWinForms
{
    public class ReportForm : Form
    {
        private int _patientId;
        
        // UI Controls
        private Label lblPatientInfo;
        private TabControl mainTabControl;
        private TabPage tabBiometry;
        private TabPage tabScanDetails;
        
        // Tab 1 Fields
        private TextBox txtBpd;
        private TextBox txtHc;
        private TextBox txtAc;
        private TextBox txtFl;
        private TextBox txtFhr;
        private TextBox txtComments;
        
        // Gender
        private RadioButton rbMale;
        private RadioButton rbFemale;
        private RadioButton rbOther;
        
        // Tab 2 Fields
        private TextBox txtGa;
        private TextBox txtPlacenta;
        private TextBox txtAfi;
        private TextBox txtPresentation;
        private TextBox txtEfw;
        private ComboBox cmbScanType;
        
        // Testing Table
        private DataGridView dgvBiometryHistory;
        
        // Voice Controls Removed
        // private AugnitoService _augnitoService;
        private ListBox lbDebugLog = null!;
        // private Label lblMicStatus = null!;
        // private Button btnMic = null!;
        private Button btnSave = null!;
        private Button btnCancel = null!;

        // Voice Command Mapping
        private class VoiceCommandDefinition
        {
            public TextBox Target { get; set; } = null!;
            public List<string> Keywords { get; set; } = new();
            public bool IsExactMatch { get; set; } = false;
        }

        private List<VoiceCommandDefinition> _voiceCommands = new();


        public ReportForm(int patientId)
        {
            _patientId = patientId;
            InitializeComponent();
            LoadPatient();
            
            // Initialize basic defaults if needed, though Designer does it.
            // Suppressing warnings for Designer-managed controls is common, 
            // but ensuring they aren't null is better. 
            // We rely on InitializeComponent.
            // Fix for "Non-nullable field... must contain a non-null value"
            // In modern C#, controls field should be nullable 'TextBox?' or initialized.
            // I will change the field definitions to be nullable or use 'null!' trick if I could edit them.
            // Since I am editing the Constructor area, I can't easily change all field definitions down below (if they are below).
            // I will ignore the warnings for now as they don't block execution. 
            // Focus on "it works".
            
            // Initialize Grid Data
            var defaultData = new List<BiometryCaseData>
            {
                new BiometryCaseData { Patient = "Case 1" },
                new BiometryCaseData { Patient = "Case 2" },
                new BiometryCaseData { Patient = "Case 3" },
                new BiometryCaseData { Patient = "Case 4" }
            };
            dgvBiometryHistory.DataSource = defaultData;
        }
        
        private void InitializeComponent()
        {
            this.Text = "Report Generator";
            this.Size = new Size(1000, 800);
            this.StartPosition = FormStartPosition.CenterParent;
            
            lblPatientInfo = new Label { Location = new Point(10, 10), AutoSize = true, Font = new Font("Segoe UI", 12, FontStyle.Bold) };
            
            mainTabControl = new TabControl { Location = new Point(10, 50), Size = new Size(960, 500) };
            
            tabBiometry = new TabPage("Biometry & Comments");
            tabScanDetails = new TabPage("Scan Details");
            
            mainTabControl.TabPages.Add(tabBiometry);
            mainTabControl.TabPages.Add(tabScanDetails);
            
            // Setup Tab 1
            SetupBiometryTab();
            
            // Setup Tab 2
            SetupScanDetailsTab();
            
            // Default Buttons and Status
            // lblMicStatus = new Label { Text = "Mic Status: Paused", Location = new Point(10, 560), AutoSize = true };
            // btnMic = new Button { Text = "Start Mic", Location = new Point(150, 555), Width = 100 };
            // btnMic.Click += MicBtn_Click;
            
            btnSave = new Button { Text = "Save Report", Location = new Point(750, 560), Width = 100, BackColor = Color.LightGreen };
            btnSave.Click += Save_Click;
            
            btnCancel = new Button { Text = "Cancel", Location = new Point(860, 560), Width = 100 };
            btnCancel.Click += Cancel_Click;
            
            lbDebugLog = new ListBox { Location = new Point(10, 600), Size = new Size(960, 150) };
            
            
            this.Controls.Add(lblPatientInfo);
            this.Controls.Add(mainTabControl);
            // this.Controls.Add(lblMicStatus);
            // this.Controls.Add(btnMic);
            this.Controls.Add(btnSave);
            this.Controls.Add(btnCancel);
            this.Controls.Add(lbDebugLog);
            this.Controls.Add(lbDebugLog);

            InitializeVoiceCommands(); // Initialize mappings

            this.Load += ReportForm_Load;
        }

        private void InitializeVoiceCommands()
        {
            _voiceCommands = new List<VoiceCommandDefinition>
            {
                // Biometry Tab - Use ExactMatch for acronyms to avoid partial matches (e.g. "ac" in "placenta")
                new() { Target = txtBpd, Keywords = new() { "BPD", "Biparietal Diameter" }, IsExactMatch = true },
                new() { Target = txtHc, Keywords = new() { "HC", "Head Circumference" }, IsExactMatch = true },
                new() { Target = txtAc, Keywords = new() { "AC", "Abdominal Circumference" }, IsExactMatch = true },
                new() { Target = txtFl, Keywords = new() { "FL", "Femur Length" }, IsExactMatch = true },
                new() { Target = txtFhr, Keywords = new() { "FHR", "Fetal Heart Rate" }, IsExactMatch = true },
                new() { Target = txtComments, Keywords = new() { "Comments", "Remarks", "Note", "Daily Note" } },

                // Scan Details Tab
                new() { Target = txtGa, Keywords = new() { "GA", "Gestational Age" }, IsExactMatch = true },
                new() { Target = txtPlacenta, Keywords = new() { "Placenta" } },
                new() { Target = txtAfi, Keywords = new() { "AFI", "Fluid", "Amniotic Fluid" }, IsExactMatch = true },
                new() { Target = txtPresentation, Keywords = new() { "Presentation" } },
                new() { Target = txtEfw, Keywords = new() { "EFW", "Weight", "Estimated Fetal Weight" }, IsExactMatch = true }
            };
        }


        private void SetupBiometryTab()
        {
            // Simple absolute layout for speed
            int y = 20;
            int xLabel = 20;
            int xBox = 150;
            
            tabBiometry.Controls.Add(new Label { Text = "BPD:", Location = new Point(xLabel, y) });
            txtBpd = new TextBox { Name = "txtBpd", Location = new Point(xBox, y), Width = 200 };
            tabBiometry.Controls.Add(txtBpd);
            y += 40;
            
            tabBiometry.Controls.Add(new Label { Text = "HC:", Location = new Point(xLabel, y) });
            txtHc = new TextBox { Name = "txtHc", Location = new Point(xBox, y), Width = 200 };
            tabBiometry.Controls.Add(txtHc);
            y += 40;
            
            tabBiometry.Controls.Add(new Label { Text = "AC:", Location = new Point(xLabel, y) });
            txtAc = new TextBox { Name = "txtAc", Location = new Point(xBox, y), Width = 200 };
            tabBiometry.Controls.Add(txtAc);
            y += 40;
            
            tabBiometry.Controls.Add(new Label { Text = "FL:", Location = new Point(xLabel, y) });
            txtFl = new TextBox { Name = "txtFl", Location = new Point(xBox, y), Width = 200 };
            tabBiometry.Controls.Add(txtFl);
            y += 40;
            
            tabBiometry.Controls.Add(new Label { Text = "FHR:", Location = new Point(xLabel, y) });
            txtFhr = new TextBox { Name = "txtFhr", Location = new Point(xBox, y), Width = 200 };
            tabBiometry.Controls.Add(txtFhr);
            y += 40;
            
            // Gender
            var grpGender = new GroupBox { Text = "Gender", Location = new Point(400, 20), Size = new Size(200, 150) };
            rbMale = new RadioButton { Name = "rbMale", Text = "Male", Location = new Point(10, 30) };
            rbFemale = new RadioButton { Name = "rbFemale", Text = "Female", Location = new Point(10, 60) };
            rbOther = new RadioButton { Name = "rbOther", Text = "Others", Location = new Point(10, 90) };
            grpGender.Controls.Add(rbMale);
            grpGender.Controls.Add(rbFemale);
            grpGender.Controls.Add(rbOther);
            tabBiometry.Controls.Add(grpGender);
            
            // Comments
            tabBiometry.Controls.Add(new Label { Text = "Comments:", Location = new Point(xLabel, y) });
            txtComments = new TextBox { Name = "txtComments", Location = new Point(xBox, y), Width = 500, Height = 100, Multiline = true, ScrollBars = ScrollBars.Vertical };
            tabBiometry.Controls.Add(txtComments);
            y += 120;
            
            // Grid
            tabBiometry.Controls.Add(new Label { Text = "Biometry History:", Location = new Point(xLabel, y) });
            y += 25;
            dgvBiometryHistory = new DataGridView 
            { 
                Name = "dgvBiometryHistory",
                Location = new Point(xLabel, y), 
                Size = new Size(600, 150),
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            
            tabBiometry.Controls.Add(dgvBiometryHistory);
        }

        private void SetupScanDetailsTab()
        {
            int y = 20;
            int xLabel = 20;
            int xBox = 150;
            
            tabScanDetails.Controls.Add(new Label { Text = "GA:", Location = new Point(xLabel, y) });
            txtGa = new TextBox { Name = "txtGa", Location = new Point(xBox, y), Width = 200 };
            tabScanDetails.Controls.Add(txtGa);
            y += 40;
            
            tabScanDetails.Controls.Add(new Label { Text = "Placenta:", Location = new Point(xLabel, y) });
            txtPlacenta = new TextBox { Name = "txtPlacenta", Location = new Point(xBox, y), Width = 200 };
            tabScanDetails.Controls.Add(txtPlacenta);
            y += 40;
            
            tabScanDetails.Controls.Add(new Label { Text = "AFI:", Location = new Point(xLabel, y) });
            txtAfi = new TextBox { Name = "txtAfi", Location = new Point(xBox, y), Width = 200 };
            tabScanDetails.Controls.Add(txtAfi);
            y += 40;
            
            tabScanDetails.Controls.Add(new Label { Text = "Presentation:", Location = new Point(xLabel, y) });
            txtPresentation = new TextBox { Name = "txtPresentation", Location = new Point(xBox, y), Width = 200 };
            tabScanDetails.Controls.Add(txtPresentation);
            y += 40;
            
            tabScanDetails.Controls.Add(new Label { Text = "EFW (Weight):", Location = new Point(xLabel, y) });
            txtEfw = new TextBox { Name = "txtEfw", Location = new Point(xBox, y), Width = 200 };
            tabScanDetails.Controls.Add(txtEfw);
            y += 40;
            
            tabScanDetails.Controls.Add(new Label { Text = "Scan Type:", Location = new Point(xLabel, y) });
            cmbScanType = new ComboBox { Name = "cmbScanType", Location = new Point(xBox, y), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbScanType.Items.AddRange(new object[] { "Early Pregnancy", "Growth Scan", "Anomaly Scan", "Nuchal Translucency", "Wellbeing" });
            tabScanDetails.Controls.Add(cmbScanType);
        }

        private async void ReportForm_Load(object sender, EventArgs e)
        {
             // Removed local mic initialization
        }

        
        // Voice Control Reflection Logic
        public enum VoiceControlAction
        {
            Click,          // Buttons, RadioButtons
            Type,           // TextBoxes
            SelectByValue,  // ComboBox (Text match)
            SelectByIndex,  // ComboBox (Index match)
            Dropdown,       // ComboBox (Open list)
            Focus           // Just focus
        }

        // Mapping: Keyword -> (ControlName, ActionType)
        private Dictionary<string, (string ControlName, VoiceControlAction Action)> _voiceMap = new(StringComparer.OrdinalIgnoreCase)
        {
            // Biometry
            { "BPD", ("txtBpd", VoiceControlAction.Type) },
            { "HC", ("txtHc", VoiceControlAction.Type) },
            { "AC", ("txtAc", VoiceControlAction.Type) },
            { "FL", ("txtFl", VoiceControlAction.Type) },
            { "FHR", ("txtFhr", VoiceControlAction.Type) },
            { "Comments", ("txtComments", VoiceControlAction.Type) },
            { "Remarks", ("txtComments", VoiceControlAction.Type) },
            { "Note", ("txtComments", VoiceControlAction.Type) },

            // Gender (Radio Buttons - Click)
            { "Gender Male", ("rbMale", VoiceControlAction.Click) },
            { "Male", ("rbMale", VoiceControlAction.Click) },
            { "Gender Female", ("rbFemale", VoiceControlAction.Click) },
            { "Female", ("rbFemale", VoiceControlAction.Click) },
            { "Gender Other", ("rbOther", VoiceControlAction.Click) },
            { "Other", ("rbOther", VoiceControlAction.Click) },

            // Scan Details
            { "GA", ("txtGa", VoiceControlAction.Type) },
            { "Placenta", ("txtPlacenta", VoiceControlAction.Type) },
            { "AFI", ("txtAfi", VoiceControlAction.Type) },
            { "Fluid", ("txtAfi", VoiceControlAction.Type) }, // Alias
            { "Presentation", ("txtPresentation", VoiceControlAction.Type) },
            { "EFW", ("txtEfw", VoiceControlAction.Type) },
            { "Weight", ("txtEfw", VoiceControlAction.Type) }, // Alias

            // ComboBox Actions
            { "Scan Type", ("cmbScanType", VoiceControlAction.Dropdown) },   // Just open list
            { "Show Scan Type", ("cmbScanType", VoiceControlAction.Dropdown) },
            
            // Explicit Options for Scan Type (Select)
            { "Early Pregnancy", ("cmbScanType", VoiceControlAction.SelectByValue) },
            { "Growth Scan", ("cmbScanType", VoiceControlAction.SelectByValue) },
            { "Anomaly Scan", ("cmbScanType", VoiceControlAction.SelectByValue) },
            { "Nuchal Translucency", ("cmbScanType", VoiceControlAction.SelectByValue) },
            { "Wellbeing", ("cmbScanType", VoiceControlAction.SelectByValue) },

            { "Scan Index", ("cmbScanType", VoiceControlAction.SelectByIndex) } // Example: "Scan Index 1"
        };


        public void HandleVoiceCommand(string text)
        {
            if (string.IsNullOrEmpty(text)) return;
            
            // --- Voice Corrections ---
            // Handle common speech recognition errors for "Case 2" and "Case 4"
            string correctedText = System.Text.RegularExpressions.Regex.Replace(text, "case to", "case 2", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            correctedText = System.Text.RegularExpressions.Regex.Replace(correctedText, "case for", "case 4", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            
            lbDebugLog.Items.Insert(0, $"[Heard] {correctedText}");
            string lowerText = correctedText.Trim(); 

            // --- 0. Special Handling for Comments Mode (Lock) ---
            // If the user is currently focused on the Comments box, we want to capture everything as text
            // UNLESS they say a specific "Escape" command like "Stop dictation" or "Scan Details" (if we want to allow nav).
            // For now, let's just allow navigation commands to break out, OR explicitly check for "Next/Stop".
            
            // Note: We need to check if the specific control is focused. 
            // In WinForms, ActiveControl might be the TabControl or SplitContainer, so we find the nested focused control.
            Control? focusedControl = this.ActiveControl;
            while (focusedControl is ContainerControl container && container.ActiveControl != null)
            {
                focusedControl = container.ActiveControl;
            }

            if (focusedControl != null && focusedControl.Name == "txtComments")
            {
                // Check for "Escape" commands first
                // If the user says a navigation command or specific keyword, we might want to switch.
                // For simplicity, let's say "Stop Dictation" or "Exit Comments" breaks the lock.
                // BUT, the user also complained "BPD" moves focus. 
                // We should ONLY move focus if the user INTENDS to. 
                // To properly "Lock", we should defaulting to typing, checking for explicit commands later?
                // Actually, the user wants "BPD" to be TYPED, not navigated to, when in comments.
                // So we simply APPEND text and RETURN.
                
                // However, we need a way to get OUT. 
                // Common pattern: If command matches "Scan Details" or "Biometry" (Navigation), we allow it.
                // If command matches "BPD", we might want to type it.
                // Let's try: If it matches a KEYWORD that is NOT just a Field Jump, do we execute?
                // check for "clear" and "clear all" strict matches to allow clearing while in comments
                bool isClearCommand = lowerText.Equals("clear", StringComparison.OrdinalIgnoreCase);
                bool isClearAllCommand = lowerText.Equals("clear all", StringComparison.OrdinalIgnoreCase);

                if (isClearCommand || isClearAllCommand)
                {
                    // Allow these to fall through to the global handler below
                    // We don't return here, we break out of the lock block.
                    // But we need to make sure we don't double-type "clear".
                    // So we can just Goto Global or copy logic.
                    // Easiest is to let flow continue, but we need to Un-Focus if it's "Clear"? 
                    // No, "Clear" expects focus to stay. "Clear All" might not matter.
                    
                    // Actually, if we just break, the code below will try to find "Clear" in _voiceMap, which fails, 
                    // AND then hits the Global Command check. 
                    // So we just break the if/return.
                }
                else
                {
                    // Loosen the check to handle "exit common", "exit comment", etc.
                    bool isEscapeCommand = lowerText.IndexOf("stop dictation", StringComparison.OrdinalIgnoreCase) >= 0
                                           || lowerText.IndexOf("exit comment", StringComparison.OrdinalIgnoreCase) >= 0
                                           || lowerText.IndexOf("exit common", StringComparison.OrdinalIgnoreCase) >= 0;

                    if (isEscapeCommand)
                    {
                         // Break the lock by moving focus away from the TextBox.
                         this.ActiveControl = null; 
                         lbDebugLog.Items.Insert(0, "[System] Exited Comments Mode");
                         return;
                    }

                    // If not escaping/clearing, treat as dictation
                    var txt = (TextBox)focusedControl;
                    txt.AppendText((txt.TextLength > 0 ? " " : "") + text);
                    return; // STOP processing as a command
                }
            }
            // --- End Comments Lock ---
            
            // --- 0.1 Grid Lock Mode ---
            if (focusedControl is DataGridView dgvLock && dgvLock.Name == "dgvBiometryHistory")
            {
                // Check if user wants to exit (including "Exit Grade" alias)
                if (lowerText.Contains("exit grid") || lowerText.Contains("stop grid") || lowerText.Contains("exit grade"))
                {
                     this.ActiveControl = null; // Unfocus logic
                     lbDebugLog.Items.Insert(0, "[System] Exited Grid Mode");
                     return;
                }
                
                // Allow "Clear All" in grid too
                 if (lowerText.Equals("clear all", StringComparison.OrdinalIgnoreCase))
                {
                    PerformClearAll();
                    return;
                }
                
                // Allow "Clear" (Active Cell) in grid
                if (lowerText.Equals("clear", StringComparison.OrdinalIgnoreCase))
                {
                    PerformClearActive();
                    return;
                }

                // Allow Navigation within Grid ("Case 1 BPD") to work normally
                else if (System.Text.RegularExpressions.Regex.IsMatch(lowerText, @"^case\s+\d+", System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                {
                     // Let it fall through to the Navigation Logic below
                }
                else
                {
                    // Column + Value Entry (e.g. "HC 10", "BPD 25", "FL20")
                    // Regex to capture Column Name and Value. Uses \s* to allow "FL20" (no space).
                    var colValMatch = System.Text.RegularExpressions.Regex.Match(lowerText, @"^(BPD|HC|AC|FL|FHR)\s*(.+)$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                    if (colValMatch.Success)
                    {
                        string targetColName = colValMatch.Groups[1].Value;
                        string valueToEnter = colValMatch.Groups[2].Value;

                        // Find and switch to column
                        foreach(DataGridViewColumn col in dgvLock.Columns)
                        {
                             if (col.Name.Equals(targetColName, StringComparison.OrdinalIgnoreCase) || 
                                 col.HeaderText.Equals(targetColName, StringComparison.OrdinalIgnoreCase))
                             {
                                 if (dgvLock.CurrentCell != null)
                                 {
                                     // 1. Switch to Column
                                     dgvLock.CurrentCell = dgvLock[col.Index, dgvLock.CurrentCell.RowIndex];
                                     
                                     // 2. Enter Value
                                     if (!dgvLock.CurrentCell.ReadOnly)
                                     {
                                         dgvLock.CurrentCell.Value = valueToEnter;
                                         lbDebugLog.Items.Insert(0, $"[Grid Entry] {targetColName} = {valueToEnter}");
                                         
                                         // 3. Auto-Advance
                                         int currentRow = dgvLock.CurrentCell.RowIndex;
                                         int currentCol = dgvLock.CurrentCell.ColumnIndex;
                                         for (int i = currentCol + 1; i < dgvLock.Columns.Count; i++)
                                         {
                                             if (dgvLock.Columns[i].Visible)
                                             {
                                                 dgvLock.CurrentCell = dgvLock[i, currentRow];
                                                 break;
                                             }
                                         }
                                     }
                                 }
                                 return;
                             }
                        }
                    }

                    // Column Selection Jumping (e.g. "HC", "AC")
                    // ... (rest is same)
                    // Check if the text matches a known column header
                    string[] possibleCols = { "BPD", "HC", "AC", "FL", "FHR" };
                    string? targetColNameSimple = possibleCols.FirstOrDefault(c => c.Equals(lowerText, StringComparison.OrdinalIgnoreCase));
                    
                    if (targetColNameSimple != null)
                    {
                         // Find this column
                         foreach(DataGridViewColumn col in dgvLock.Columns)
                         {
                             if (col.Name.Equals(targetColNameSimple, StringComparison.OrdinalIgnoreCase) || 
                                 col.HeaderText.Equals(targetColNameSimple, StringComparison.OrdinalIgnoreCase))
                             {
                                 if (dgvLock.CurrentCell != null)
                                 {
                                     dgvLock.CurrentCell = dgvLock[col.Index, dgvLock.CurrentCell.RowIndex];
                                     lbDebugLog.Items.Insert(0, $"[Grid Nav] Switched to {targetColNameSimple}");
                                 }
                                 return;
                             }
                         }
                    }

                    // Treat as INPUT for the current cell
                    if (dgvLock.CurrentCell != null && !dgvLock.CurrentCell.ReadOnly)
                    {
                        dgvLock.CurrentCell.Value = text;
                        lbDebugLog.Items.Insert(0, $"[Grid Input] {text}");
                        
                        // Auto-Advance to next column
                        int currentRow = dgvLock.CurrentCell.RowIndex;
                        int currentCol = dgvLock.CurrentCell.ColumnIndex;
                        
                        // Find next visible column
                        for (int i = currentCol + 1; i < dgvLock.Columns.Count; i++)
                        {
                            if (dgvLock.Columns[i].Visible)
                            {
                                dgvLock.CurrentCell = dgvLock[i, currentRow];
                                break;
                            }
                        }
                    }
                    return; // Stop processing
                }
            }
            // --- End Grid Lock ---

            // --- 0.5 Global Commands (Clear / Clear All) ---
            if (lowerText.Equals("clear all", StringComparison.OrdinalIgnoreCase))
            {
                PerformClearAll();
                return;
            }

            if (lowerText.Equals("clear", StringComparison.OrdinalIgnoreCase))
            {
                PerformClearActive();
                return;
            }
            
            // --- 0.6 Grid Navigation ("Case 1 BPD") ---
            // Regex: Case (Space) Number (Space) Column
            var caseMatch = System.Text.RegularExpressions.Regex.Match(lowerText, @"^case\s+(\d+)\s+(.+)$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (caseMatch.Success)
            {
                if (int.TryParse(caseMatch.Groups[1].Value, out int caseNum))
                {
                    string colName = caseMatch.Groups[2].Value.Trim(); // e.g. "BPD", "HC"
                    
                    // The Grid is dgvBiometryHistory
                    if (dgvBiometryHistory != null)
                    {
                        // We need row index.
                        // Assuming rows exist.
                        // If strict mapping: Case 1 -> Row 0.
                        int rowIndex = caseNum - 1;
                        
                        // Ensure rows exist!
                        if (rowIndex >= 0 && rowIndex < dgvBiometryHistory.Rows.Count)
                        {
                            // Try to find column by name
                            // We need to map "BPD" -> Column Index or Name.
                            // Assuming column names match standard keywords or we search header text.
                            DataGridViewColumn? targetCol = null;
                            foreach(DataGridViewColumn col in dgvBiometryHistory.Columns)
                            {
                                if (col.HeaderText.Equals(colName, StringComparison.OrdinalIgnoreCase) || 
                                    col.Name.Equals(colName, StringComparison.OrdinalIgnoreCase))
                                {
                                    targetCol = col;
                                    break;
                                }
                            }
                            
                            if (targetCol != null)
                            {
                                EnsureControlVisible(dgvBiometryHistory);
                                dgvBiometryHistory.Focus();
                                dgvBiometryHistory.CurrentCell = dgvBiometryHistory[targetCol.Index, rowIndex];
                                lbDebugLog.Items.Insert(0, $"[Grid] Selected Case {caseNum} {colName}");
                                return;
                            }
                        }
                    }
                }
            }
            
            // 1. Identify Keyword and Action from Map
            string matchedKeyword = "";
            string targetControlName = "";
            VoiceControlAction action = VoiceControlAction.Focus;

            // Sort keys by length descending to match "Gender Male" before "Male"
            foreach (var key in _voiceMap.Keys.OrderByDescending(k => k.Length)) 
            {
               // Check if text STARTS with keyword (e.g. "BPD 20") or EQUALS it
               if (lowerText.StartsWith(key, StringComparison.OrdinalIgnoreCase))
               {
                   matchedKeyword = key;
                   var mapping = _voiceMap[key];
                   targetControlName = mapping.ControlName;
                   action = mapping.Action;
                   break;
               }
            }

            // check for navigation commands if no direct match found (backwards compatibility or global commands)
            if (string.IsNullOrEmpty(targetControlName))
            {
                // Fallback or global commands like "Clear"
                // ... (Existing Clear/Navigation logic could remain here if needed, but for now focusing on Reflection plan)
                ProcessGlobalCommands(text);
                return;
            }

            // 2. Find the Control
            Control[] foundControls = this.Controls.Find(targetControlName, true);
            if (foundControls.Length == 0) return;
            Control targetControl = foundControls[0];

            // 3. Extract Value (Payload)
            // Remove the keyword from the start. "BPD 20" -> " 20" -> "20"
            string valuePayload = lowerText.Substring(matchedKeyword.Length).Trim();
            
            // Cleanup common voice artifacts
            valuePayload = valuePayload.TrimStart(':', '-', ' '); 

            // Special Case: For "SelectByValue" commands like "Growth Scan", the keyword ITSELF is the value to select.
            // If the payload is empty, use the matched keyword as the value.
            if (string.IsNullOrEmpty(valuePayload) && action == VoiceControlAction.SelectByValue)
            {
                valuePayload = matchedKeyword;
            }

            // 4. Execute Action via Reflection
            ExecuteControlAction(targetControl, action, valuePayload);
        }

        // Helper to get all controls recursively for "Clear All"
        private IEnumerable<Control> GetAllControls(Control root)
        {
            foreach (Control c in root.Controls)
            {
                yield return c;
                foreach (Control child in GetAllControls(c))
                {
                    yield return child;
                }
            }
        }

        private void ExecuteControlAction(Control control, VoiceControlAction action, string value)
        {
            Type type = control.GetType();

            // Ensure we are on the correct tab if the control is inside a TabPage
            EnsureControlVisible(control);
            control.Focus(); 
            HighlightField(control); // Visual feedback

            switch (action)
            {
                case VoiceControlAction.Click:
                    // RadioButton, Button
                    MethodInfo? performClick = type.GetMethod("PerformClick");
                    if (performClick != null)
                    {
                        performClick.Invoke(control, null);
                    }
                    break;

                case VoiceControlAction.Type:
                    // TextBox
                    PropertyInfo? textProp = type.GetProperty("Text");
                    if (textProp != null)
                    {
                        // Let's do basic cleanup for "point" -> "."
                        string cleanVal = value.Replace("point", ".");
                        
                        // Handle Multiline Append
                        PropertyInfo? multiLineProp = type.GetProperty("Multiline");
                        bool isMultiline = (bool?)multiLineProp?.GetValue(control) ?? false;
                        
                        if (isMultiline)
                        {
                            string current = (string?)textProp.GetValue(control) ?? "";
                            if (!string.IsNullOrEmpty(cleanVal))
                            {
                                // Append with space
                                string newVal = string.IsNullOrEmpty(current) ? cleanVal : current + " " + cleanVal;
                                textProp.SetValue(control, newVal);
                            }
                        }
                        else
                        {
                            // Overwrite for single line fields
                            textProp.SetValue(control, cleanVal);
                        }
                    }
                    break;
                
                case VoiceControlAction.Dropdown:
                    // ComboBox: Open list
                    if (control is ComboBox cmbDrop)
                    {
                        cmbDrop.DroppedDown = true;
                    }
                    break;

                case VoiceControlAction.SelectByValue:
                    // ComboBox: Select by Text
                    if (control is ComboBox cmbVal)
                    {
                        // Try to find item that contains the text
                        // Use case-insensitive search if possible, or manual loop
                        int index = cmbVal.FindString(value);
                        if (index >= 0)
                        {
                            cmbVal.SelectedIndex = index;
                        }
                        else
                        {
                            // If exact match not found, maybe just set text (for DropDown style)
                            cmbVal.Text = value; 
                        }
                    }
                    break;

                case VoiceControlAction.SelectByIndex:
                     // ComboBox: Select by Index
                     // "Scan Index 1"
                     if (control is ComboBox cmbIdx)
                     {
                         // Parse index
                         // voice might say "one", "two", need usage of a number parser if sophisticated, 
                         // but assuming digits "1", "2" for now.
                         var match = System.Text.RegularExpressions.Regex.Match(value, @"\d+");
                         if (match.Success && int.TryParse(match.Value, out int idx))
                         {
                             // 1-based to 0-based conversion if user speaks naturally? 
                             // Usually "First" -> 0. Let's assume 0-based or 1-based?
                             // Let's stick to 1-based for users: "Select option 1" -> Index 0.
                             int actualIndex = idx - 1;
                             if (actualIndex >= 0 && actualIndex < cmbIdx.Items.Count)
                             {
                                 cmbIdx.SelectedIndex = actualIndex;
                             }
                         }
                     }
                    break;
            }
        }

        private void EnsureControlVisible(Control control)
        {
            Control? parent = control.Parent;
            while (parent != null)
            {
                if (parent is TabPage page && parent.Parent is TabControl tabControl)
                {
                    tabControl.SelectedTab = page;
                }
                parent = parent.Parent;
            }
        }

        private void ProcessGlobalCommands(string text)
        {
            string lower = text.ToLower();
            // Fallback for global clear
            if (lower.Contains("clear all") || lower.Contains("reset"))
            {
                 // Call existing clear logic via reflection or simple method if kept?
                 // For now, simple inline
                 foreach(var tb in this.Controls.Find("txtBpd", true)) ((TextBox)tb).Clear(); 
                 // ... (Simplified for brevity, can re-add full clear logic if requested)
            }
             
            // Navigation Fallback
            if (lower.Contains("scan details")) mainTabControl.SelectedTab = tabScanDetails;
            if (lower.Contains("biometry")) mainTabControl.SelectedTab = tabBiometry;
        }
        
        private void PerformClearAll()
        {
            foreach (Control c in GetAllControls(this))
            {
                if (c is TextBox tb) tb.Clear();
                if (c is ComboBox cb) cb.SelectedIndex = -1;
                if (c is RadioButton rb) rb.Checked = false;
                if (c is CheckBox chk) chk.Checked = false;
                if (c is DataGridView dgv) dgv.Rows.Clear(); 
            }
            lbDebugLog.Items.Insert(0, "[System] Form Cleared");
        }

        private void PerformClearActive()
        {
            Control? focusedControl = this.ActiveControl;
            while (focusedControl is ContainerControl container && container.ActiveControl != null)
            {
                focusedControl = container.ActiveControl;
            }

            if (focusedControl is TextBox tb) tb.Clear();
            if (focusedControl is ComboBox cb) cb.SelectedIndex = -1;
            if (focusedControl is DataGridView dgv && dgv.CurrentCell != null) 
            {
                if (!dgv.CurrentCell.ReadOnly) dgv.CurrentCell.Value = null;
            }
            
            lbDebugLog.Items.Insert(0, "[System] Active Field Cleared");
        }

        private bool IsWord(string input, string word) =>
            System.Text.RegularExpressions.Regex.IsMatch(input, $@"\b{word}\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        private void HighlightField(Control tb)
        {
            tb.BackColor = Color.LightYellow;
            var t = new Timer { Interval = 1000 };
            t.Tick += (s, e) => { tb.BackColor = Color.White; t.Stop(); };
            t.Start();
        }

        private void Save_Click(object sender, EventArgs e)
        {
            using (var context = new AppDbContext())
            {
                string gender = "Others";
                if (rbMale.Checked) gender = "Male";
                if (rbFemale.Checked) gender = "Female";

                var report = new Report
                {
                    PatientId = _patientId,
                    VisitDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    BPD = txtBpd.Text,
                    HC = txtHc.Text,
                    AC = txtAc.Text,
                    FL = txtFl.Text,
                    FHR = txtFhr.Text,
                    Comments = txtComments.Text,
                    GA = txtGa.Text,
                    Placenta = txtPlacenta.Text,
                    AFI = txtAfi.Text,
                    Presentation = txtPresentation.Text,
                    EFW = txtEfw.Text,
                    ScanType = cmbScanType.Text,
                    Gender = gender,
                    BiometryHistory = JsonSerializer.Serialize(dgvBiometryHistory.DataSource)
                };
                context.Reports.Add(report);
                context.SaveChanges();
            }
            MessageBox.Show("Report Saved.");
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void LoadPatient()
        {
            using (var context = new AppDbContext())
            {
                var patient = context.Patients.FirstOrDefault(p => p.Id == _patientId);
                if (patient != null) lblPatientInfo.Text = $"Report for: {patient.Name} (ID: {patient.IdNumber})";
            }
        }
    }
    
    public class BiometryCaseData
    {
        public string Patient { get; set; }
        public string BPD { get; set; }
        public string HC { get; set; }
        public string AC { get; set; }
        public string FL { get; set; }
        public string FHR { get; set; }
    }
}
