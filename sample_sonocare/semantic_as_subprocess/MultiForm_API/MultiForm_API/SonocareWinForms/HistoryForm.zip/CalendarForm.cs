using System;
using System.Drawing;
using System.Windows.Forms;
using SonocareWinForms.Services;

namespace SonocareWinForms
{
    public class CalendarForm : Form
    {
        private TextBox txtPatientName;
        private TextBox txtPatientId;
        private TextBox txtVisitDate;
        private TextBox txtDOB; // New Field
        private TextBox txtNotes;
        private MonthCalendar calendar;
        
        // Helper to track which box is asking for date
        private TextBox _dateTargetBox; 

        public CalendarForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Sonocare - Calendar & Notes";
            this.Size = new Size(600, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            // REMOVED: lblTitle ("Doctor's Schedule Notes")

            // Layout Constants
            int labelX = 50;
            int textX = 180;
            int startY = 30;
            int gap = 40;

            // 1. Patient Name
            var lblName = new Label { Text = "Patient Name:", Location = new Point(labelX, startY), AutoSize = true };
            txtPatientName = new TextBox { Location = new Point(textX, startY), Width = 200 };
            
            // 2. Patient ID
            int y = startY + gap;
            var lblId = new Label { Text = "Patient ID:", Location = new Point(labelX, y), AutoSize = true };
            txtPatientId = new TextBox { Location = new Point(textX, y), Width = 200 };

            // 3. DOB (New)
            y += gap;
            var lblDOB = new Label { Text = "Date of Birth:", Location = new Point(labelX, y), AutoSize = true };
            txtDOB = new TextBox { Location = new Point(textX, y), Width = 200 };
            // Event to show calendar
            txtDOB.Click += (s, e) => ShowCalendar(txtDOB);
            txtDOB.Enter += (s, e) => ShowCalendar(txtDOB);

            // 4. Visit Date
            y += gap;
            var lblDate = new Label { Text = "Visit Date:", Location = new Point(labelX, y), AutoSize = true };
            txtVisitDate = new TextBox { Location = new Point(textX, y), Width = 200 };
            // Event to show calendar
            txtVisitDate.Click += (s, e) => ShowCalendar(txtVisitDate);
            txtVisitDate.Enter += (s, e) => ShowCalendar(txtVisitDate);

            // 5. Notes
            y += gap + 20;
            var lblNotes = new Label
            {
                Text = "Daily Notes (Dictation Supported):",
                Location = new Point(labelX, y),
                AutoSize = true
            };
            
            y += 20;
            txtNotes = new TextBox
            {
                Location = new Point(labelX, y),
                Size = new Size(500, 150),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical
            };

            // 6. Calendar (Hidden initially)
            calendar = new MonthCalendar
            {
                Location = new Point(textX, y), // Default pos, will move
                MaxSelectionCount = 1,
                Visible = false // HIDDEN
            };
            calendar.DateSelected += Calendar_DateSelected;

            var btnClose = new Button
            {
                Text = "Close",
                Location = new Point(450, 500),
                Size = new Size(100, 30)
            };
            btnClose.Click += (s, e) => this.Close();

            // Add Controls
            this.Controls.Add(lblName);
            this.Controls.Add(txtPatientName);
            this.Controls.Add(lblId);
            this.Controls.Add(txtPatientId);
            this.Controls.Add(lblDOB);
            this.Controls.Add(txtDOB); // Add DOB
            this.Controls.Add(lblDate);
            this.Controls.Add(txtVisitDate);
            this.Controls.Add(lblNotes);
            this.Controls.Add(txtNotes);
            this.Controls.Add(calendar); // Add Calendar logic
            this.Controls.Add(btnClose);
            
            // Clicking form hides calendar
            this.Click += (s,e) => calendar.Visible = false;
        }

        private void ShowCalendar(TextBox target)
        {
            _dateTargetBox = target;
            // Position calendar near the textbox
            calendar.Location = new Point(target.Left, target.Bottom + 5);
            calendar.Visible = true;
            calendar.BringToFront();
        }

        private void Calendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            if (_dateTargetBox != null)
            {
                _dateTargetBox.Text = e.Start.ToShortDateString();
                calendar.Visible = false;
                
                // Move focus to next field?
                if (_dateTargetBox == txtDOB) txtVisitDate.Focus();
                else if (_dateTargetBox == txtVisitDate) txtNotes.Focus();
            }
        }

        public void HandleVoiceCommand(string text)
        {
            if (InvokeRequired) { Invoke(new Action<string>(HandleVoiceCommand), text); return; }

            string lowerText = text.ToLower();

            // CLEAR COMMANDS (Moved to top)
            if (lowerText == "clear" || lowerText == "clear field")
            {
                if (this.ActiveControl is TextBox tb) tb.Clear();
                return;
            }

            if (lowerText == "clear all" || lowerText == "reset form")
            {
                txtPatientName.Clear();
                txtPatientId.Clear();
                txtDOB.Clear();
                txtVisitDate.Clear();
                txtNotes.Clear();
                calendar.Visible = false;
                return;
            }
            
            // 1. NOTES MODE (Dictation Support)
            if (this.ActiveControl == txtNotes)
            {
                if (lowerText.Contains("comments over") || lowerText.Contains("comment over") || 
                    lowerText.Contains("notes over") || lowerText.Contains("note over"))
                {
                    // Exit Notes Mode
                    this.Focus(); // Unfocus text box
                    return;
                }
                
                // Append everything else
                txtNotes.AppendText(text + " ");
                return;
            }

            TextBox targetBox = null;
            string keyword = "";

            // Mapping Logic (Order matters for overlapping keywords like "date")
            if (lowerText.Contains("patient name") || lowerText.Contains("patient's name")) { targetBox = txtPatientName; keyword = "patient name"; }
            else if (lowerText.Contains("patient id") || lowerText.Contains("id number")) { targetBox = txtPatientId; keyword = "patient id"; }
            else if (lowerText.Contains("date of birth") || lowerText.Contains("dob")) { targetBox = txtDOB; keyword = "dob"; if (keyword=="dob" && !lowerText.Contains("dob")) keyword="date of birth"; }
            else if (lowerText.Contains("visit date")) { targetBox = txtVisitDate; keyword = "visit date"; }
            else if (lowerText.Contains("date")) { targetBox = txtVisitDate; keyword = "date"; } // Fallback for "date" -> visit date
            else if (lowerText.Contains("notes") || lowerText.Contains("note")) { targetBox = txtNotes; keyword = "note"; }

            // Hide Calendar if navigating
            if (targetBox != null && targetBox != _dateTargetBox)
            {
                calendar.Visible = false;
            }

            if (targetBox != null)
            {
                targetBox.Focus();
                string cleanText = text;
                
                // Keyword stripping
                if (lowerText.Contains(keyword))
                {
                     string pattern = $@"^\s*{keyword}[:\s-]*";
                     // Special case for multi-word
                     if (keyword == "date of birth") pattern = @"^\s*date of birth[:\s-]*";
                     
                     cleanText = System.Text.RegularExpressions.Regex.Replace(cleanText, pattern, "", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                }

                if (targetBox == txtNotes) targetBox.AppendText(cleanText + " ");
                else if (!string.IsNullOrWhiteSpace(cleanText)) targetBox.Text = cleanText.Trim();
                
                HighlightField(targetBox);
            }
            // ... (Editing commands and default typing logic same as before) ...
            // EDITING COMMANDS
            if (this.ActiveControl is TextBox activeTxt)
            {
                if (lowerText.Contains("delete last word"))
                {
                   if (!string.IsNullOrEmpty(activeTxt.Text))
                   {
                        string val = activeTxt.Text.TrimEnd();
                        int lastSpace = val.LastIndexOf(' ');
                        if (lastSpace >= 0) activeTxt.Text = val.Substring(0, lastSpace);
                        else activeTxt.Text = "";
                        activeTxt.SelectionStart = activeTxt.Text.Length;
                   }
                   return;
                }
                if (lowerText.Contains("delete last line"))
                {
                   if (!string.IsNullOrEmpty(activeTxt.Text))
                   {
                        int lastNewLine = activeTxt.Text.LastIndexOf(Environment.NewLine);
                        if (lastNewLine >= 0) activeTxt.Text = activeTxt.Text.Substring(0, lastNewLine);
                        else activeTxt.Text = "";
                        activeTxt.SelectionStart = activeTxt.Text.Length;
                   }
                   return;
                }
            }

            // Default: If no keyword matched, just type
            if (targetBox == null && this.ActiveControl is TextBox currentBox)
            {
                 currentBox.AppendText(text + " ");
            }
        }
        
        private void HighlightField(TextBox tb)
        {
            tb.BackColor = Color.LightYellow;
            var t = new Timer { Interval = 1000 };
            t.Tick += (s, e) => { tb.BackColor = Color.White; t.Stop(); };
            t.Start();
        }
    }
}
